using VerificationAPI.Services;

namespace VerificationAPI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            var xsdPath = Path.Combine(builder.Environment.ContentRootPath, "Schemas", "Video.xsd");
            builder.Services.AddSingleton(new XmlValidationService(xsdPath));
            builder.Services.AddSingleton<XmlConverter>();

            builder.Services
                .AddControllers()
                .AddXmlSerializerFormatters();

            var app = builder.Build();

            // Configure the HTTP request pipeline.

            //app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
